package com.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShopSecApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShopSecApplication.class, args);
	}

}
